import numpy as np
import matplotlib.pyplot as plt


def load_image(path, max_side=640, gray=False):
    img = plt.imread(path).astype(np.float64)
    if img.max() > 1.0:
        img = img / 255.0
    if img.ndim == 3:
        img = img[..., :3]
        if gray:
            img = img @ np.array([0.299, 0.587, 0.114])
    step = int(np.ceil(max(img.shape[:2]) / max_side))
    if step > 1:
        img = img[::step, ::step]
    return img
