from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from filtering import conv2d_same, gaussian_blur_color
from padding import pad_replicate
from utils import load_image

IMG = "data/glavo-field-5932123_1920.jpg"
PARAMS = [(5, 1.0), (11, 2.0), (21, 4.0)]


def laplacian_var(gray):
    lap = np.array([[0, -1, 0], [-1, 4, -1], [0, -1, 0]], dtype=np.float64)
    return conv2d_same(gray, lap, pad_replicate).var()


def main():
    Path("figures").mkdir(exist_ok=True)
    rgb = load_image(IMG)
    print("image:", rgb.shape)
    print(f"{'params':>18} {'laplacian_var':>15}")
    print(f"{'original':>18} {laplacian_var(rgb.mean(axis=2)):>15.5f}")

    panels = [(rgb, "original")]
    for ksize, sigma in PARAMS:
        out = np.clip(gaussian_blur_color(rgb, ksize, sigma), 0.0, 1.0)
        panels.append((out, f"k={ksize}, sigma={sigma}"))
        label = f"k={ksize}, sigma={sigma:g}"
        print(f"{label:>18} {laplacian_var(out.mean(axis=2)):>15.5f}")

    r0, c0, size = rgb.shape[0] // 3, rgb.shape[1] // 3, 150

    fig, axes = plt.subplots(2, len(panels), figsize=(4 * len(panels), 7))
    for j, (im, title) in enumerate(panels):
        axes[0, j].imshow(im)
        axes[0, j].set_title(title)
        axes[0, j].axis("off")
        axes[1, j].imshow(im[r0:r0 + size, c0:c0 + size])
        axes[1, j].set_title("crop")
        axes[1, j].axis("off")
    fig.tight_layout()
    fig.savefig("figures/task3_blur.png", dpi=150)
    plt.close(fig)
    print("saved: figures/task3_blur.png")


if __name__ == "__main__":
    main()
