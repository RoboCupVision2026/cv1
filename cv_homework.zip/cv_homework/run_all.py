import task2_kernel
import task3_blur
import task4_padding


def main():
    print("=" * 60)
    print("Task 2: 2D Gaussian kernel")
    print("=" * 60)
    task2_kernel.main()
    print()
    print("=" * 60)
    print("Task 3: manual Gaussian blur")
    print("=" * 60)
    task3_blur.main()
    print()
    print("=" * 60)
    print("Task 4: manual padding")
    print("=" * 60)
    task4_padding.main()


if __name__ == "__main__":
    main()
