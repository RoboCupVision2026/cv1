import numpy as np


def pad_zero(img, p):
    h, w = img.shape
    out = np.zeros((h + 2 * p, w + 2 * p), dtype=img.dtype)
    out[p:p + h, p:p + w] = img
    return out


def pad_replicate(img, p):
    h, w = img.shape
    rows = np.clip(np.arange(-p, h + p), 0, h - 1)
    cols = np.clip(np.arange(-p, w + p), 0, w - 1)
    return img[np.ix_(rows, cols)]
