import numpy as np


def gaussian_kernel_2d(ksize, sigma):
    ax = np.arange(ksize) - (ksize - 1) / 2
    xx, yy = np.meshgrid(ax, ax)
    g = np.exp(-(xx ** 2 + yy ** 2) / (2 * sigma ** 2))
    return g / g.sum()
