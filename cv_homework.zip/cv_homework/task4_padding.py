from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle

from filtering import gaussian_blur_color
from padding import pad_replicate, pad_zero
from utils import load_image

IMG = "data/glavo-field-5932123_1920.jpg"
KSIZE = 61
SIGMA = 10.0


def plot_padding_grid(path):
    small = np.arange(1, 37).reshape(6, 6)
    p = 2
    panels = [
        ("original 6x6", small, None),
        ("zero padding p=2", pad_zero(small, p), p),
        ("replicate padding p=2", pad_replicate(small, p), p),
    ]

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, (title, arr, pad) in zip(axes, panels):
        ax.imshow(arr, cmap="Blues", vmin=0, vmax=36)
        ax.set_title(title)
        for i in range(arr.shape[0]):
            for j in range(arr.shape[1]):
                ax.text(j, i, int(arr[i, j]), ha="center", va="center", fontsize=7)
        if pad is not None:
            ax.add_patch(Rectangle((pad - 0.5, pad - 0.5),
                                   small.shape[1], small.shape[0],
                                   fill=False, edgecolor="red", linewidth=2))
        ax.set_xticks([])
        ax.set_yticks([])
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def border_mean(img, width=5):
    parts = [img[:width].ravel(), img[-width:].ravel(),
             img[:, :width].ravel(), img[:, -width:].ravel()]
    return np.concatenate(parts).mean()


def plot_edge_effect(rgb, path):
    out_zero = np.clip(gaussian_blur_color(rgb, KSIZE, SIGMA, pad_zero), 0, 1)
    out_rep = np.clip(gaussian_blur_color(rgb, KSIZE, SIGMA, pad_replicate), 0, 1)

    diff = np.abs(out_zero - out_rep)
    diff_vis = diff / diff.max() if diff.max() > 0 else diff

    size = 140
    corner = (slice(0, size), slice(0, size))

    panels = [
        (rgb, "original"),
        (out_zero, f"zero padding  k={KSIZE}"),
        (out_rep, f"replicate padding  k={KSIZE}"),
        (diff_vis, "|zero - replicate|  (normalized)"),
    ]

    fig, axes = plt.subplots(2, 4, figsize=(18, 7))
    for j, (im, title) in enumerate(panels):
        axes[0, j].imshow(im)
        axes[0, j].set_title(title)
        axes[0, j].axis("off")
        axes[1, j].imshow(im[corner])
        axes[1, j].set_title("top-left corner")
        axes[1, j].axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)

    print(f"border mean  zero      = {border_mean(out_zero):.4f}")
    print(f"border mean  replicate = {border_mean(out_rep):.4f}")
    print(f"max |zero - replicate| = {diff.max():.4f}")


def main():
    Path("figures").mkdir(exist_ok=True)
    rgb = load_image(IMG)
    print("image:", rgb.shape)
    plot_padding_grid("figures/task4_padding_grid.png")
    plot_edge_effect(rgb, "figures/task4_edge_effect.png")
    print("saved: figures/task4_padding_grid.png, figures/task4_edge_effect.png")


if __name__ == "__main__":
    main()
