import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

from gaussian_kernel import gaussian_kernel_2d
from padding import pad_replicate


def conv2d_same(img, kernel, pad_fn=pad_replicate):
    p = kernel.shape[0] // 2
    padded = pad_fn(img.astype(np.float64), p)
    win = sliding_window_view(padded, kernel.shape)
    return np.einsum("ijkl,kl->ij", win, kernel)


def gaussian_blur(img, ksize, sigma, pad_fn=pad_replicate):
    return conv2d_same(img, gaussian_kernel_2d(ksize, sigma), pad_fn)


def gaussian_blur_color(img, ksize, sigma, pad_fn=pad_replicate):
    if img.ndim == 2:
        return gaussian_blur(img, ksize, sigma, pad_fn)
    channels = [gaussian_blur(img[..., c], ksize, sigma, pad_fn)
                for c in range(img.shape[2])]
    return np.stack(channels, axis=-1)
