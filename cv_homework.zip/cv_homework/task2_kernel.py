from pathlib import Path

import cv2
import matplotlib.pyplot as plt
import numpy as np

from gaussian_kernel import gaussian_kernel_2d

PARAMS = [(5, 1.0), (11, 2.0), (21, 4.0)]


def cv_kernel_2d(ksize, sigma):
    k1d = cv2.getGaussianKernel(ksize, sigma)
    return k1d @ k1d.T


def compare():
    print(f"{'ksize':>5} {'sigma':>6} {'max|diff|':>12} {'sum':>19} {'symmetric':>10}")
    for ksize, sigma in PARAMS:
        mine = gaussian_kernel_2d(ksize, sigma)
        ref = cv_kernel_2d(ksize, sigma)
        print(f"{ksize:>5} {sigma:>6.1f} {np.abs(mine - ref).max():>12.3e} "
              f"{mine.sum():>19.15f} {str(np.allclose(mine, mine.T)):>10}")


def plot_heatmap(path):
    fig, axes = plt.subplots(1, len(PARAMS), figsize=(4.5 * len(PARAMS), 4))
    for ax, (ksize, sigma) in zip(axes, PARAMS):
        g = gaussian_kernel_2d(ksize, sigma)
        im = ax.imshow(g, cmap="viridis")
        ax.set_title(f"ksize={ksize}, sigma={sigma}")
        ax.set_xlabel("column j")
        ax.set_ylabel("row i")
        fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_surface(path):
    fig = plt.figure(figsize=(4.5 * len(PARAMS), 3.8))
    for i, (ksize, sigma) in enumerate(PARAMS, 1):
        g = gaussian_kernel_2d(ksize, sigma)
        ax = fig.add_subplot(1, len(PARAMS), i, projection="3d")
        X, Y = np.meshgrid(np.arange(ksize), np.arange(ksize))
        ax.plot_surface(X, Y, g, cmap="viridis", linewidth=0, antialiased=True)
        ax.set_title(f"ksize={ksize}, sigma={sigma}")
        ax.set_xlabel("j")
        ax.set_ylabel("i")
        ax.set_zlim(0, 0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main():
    Path("figures").mkdir(exist_ok=True)
    compare()
    plot_heatmap("figures/task2_heatmap.png")
    plot_surface("figures/task2_surface.png")
    print("saved: figures/task2_heatmap.png, figures/task2_surface.png")


if __name__ == "__main__":
    main()
